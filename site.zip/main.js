(function () {
  "use strict";
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var hasGsap = typeof window.gsap !== "undefined";
  if (hasGsap && window.ScrollTrigger) gsap.registerPlugin(ScrollTrigger);

  /* ================= slider before/after ================= */
  var ba = document.getElementById("baSlider");
  if (ba) {
    var pos = 50, interacted = false, sweep = null;
    function setPos(p) {
      pos = Math.max(2, Math.min(98, p));
      ba.style.setProperty("--pos", pos + "%");
      ba.setAttribute("aria-valuenow", Math.round(pos));
    }
    function stopSweep() {
      interacted = true;
      if (sweep) { sweep.kill(); sweep = null; }
    }
    function fromPointer(e) {
      var r = ba.getBoundingClientRect();
      setPos(((e.clientX - r.left) / r.width) * 100);
    }
    ba.addEventListener("pointerdown", function (e) {
      stopSweep();
      ba.setPointerCapture(e.pointerId);
      fromPointer(e);
      function move(ev) { fromPointer(ev); }
      function up() {
        ba.removeEventListener("pointermove", move);
        ba.removeEventListener("pointerup", up);
        ba.removeEventListener("pointercancel", up);
      }
      ba.addEventListener("pointermove", move);
      ba.addEventListener("pointerup", up);
      ba.addEventListener("pointercancel", up);
    });
    ba.addEventListener("keydown", function (e) {
      if (e.key === "ArrowLeft") { stopSweep(); setPos(pos - 4); e.preventDefault(); }
      if (e.key === "ArrowRight") { stopSweep(); setPos(pos + 4); e.preventDefault(); }
    });

    if (!reduced && hasGsap) {
      var sweepObj = { p: 50 };
      ScrollTrigger.create({
        trigger: ba,
        start: "top 75%",
        once: true,
        onEnter: function () {
          if (interacted) return;
          sweep = gsap.to(sweepObj, {
            p: 78, duration: 1.6, ease: "power2.inOut", yoyo: true, repeat: 1,
            onUpdate: function () { if (!interacted) setPos(sweepObj.p); },
            onComplete: function () {
              if (interacted) return;
              sweep = gsap.to(sweepObj, {
                p: 24, duration: 2.2, ease: "power2.inOut", yoyo: true, repeat: -1,
                onUpdate: function () { if (!interacted) setPos(sweepObj.p); }
              });
            }
          });
        }
      });
    }
  }

  /* ================= filter galeri (tab + indeks) ================= */
  var items = Array.prototype.slice.call(document.querySelectorAll(".g-item"));
  var tabs = Array.prototype.slice.call(document.querySelectorAll(".tab"));
  var rows = Array.prototype.slice.call(document.querySelectorAll(".idx-row"));
  var galCount = document.getElementById("galCount");
  var grid = document.getElementById("grid");

  function setFilter(name, scrollToGallery) {
    var visible = 0;
    items.forEach(function (it) {
      var show = name === "all" || it.getAttribute("data-cat") === name;
      it.classList.toggle("is-hidden", !show);
      if (show) visible++;
    });
    if (galCount) galCount.textContent = visible;
    tabs.forEach(function (t) {
      t.classList.toggle("is-active", t.getAttribute("data-filter") === name);
    });
    rows.forEach(function (r) {
      r.classList.toggle("is-active", r.getAttribute("data-filter") === name);
    });
    if (hasGsap && window.ScrollTrigger) ScrollTrigger.refresh();
    if (scrollToGallery) {
      var gal = document.getElementById("galeri");
      var targetY = gal.getBoundingClientRect().top + window.scrollY - 70;
      window.scrollTo({ top: targetY, behavior: reduced ? "auto" : "smooth" });
    }
  }
  tabs.forEach(function (t) {
    t.addEventListener("click", function () { setFilter(t.getAttribute("data-filter"), false); });
  });
  rows.forEach(function (r) {
    r.addEventListener("click", function () { setFilter(r.getAttribute("data-filter"), true); });
  });

  /* ================= FAQ akordeon ================= */
  document.querySelectorAll(".faq-item").forEach(function (item) {
    var btn = item.querySelector(".faq-q");
    btn.addEventListener("click", function () {
      var open = item.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  });

  /* ================= statistik tanpa GSAP (fallback / reduced) ================= */
  function finalStats() {
    document.querySelectorAll(".stat-num").forEach(function (el) {
      el.textContent = el.getAttribute("data-count");
    });
  }

  if (reduced || !hasGsap || !window.ScrollTrigger) {
    finalStats();
    return;
  }

  /* ================= GSAP: gerak penuh ================= */
  var mm = gsap.matchMedia();
  mm.add("(prefers-reduced-motion: no-preference)", function () {

    /* progress bar */
    gsap.to(".progress", {
      scaleX: 1, ease: "none",
      scrollTrigger: { trigger: document.body, start: "top top", end: "bottom bottom", scrub: 0.3 }
    });

    /* hero: headline per baris */
    gsap.from(".hline-in", {
      yPercent: 110, duration: 1.05, ease: "power4.out", stagger: 0.13, delay: 0.1
    });
    gsap.from(".hero-kicker", { opacity: 0, x: -24, duration: 0.7, ease: "power3.out" });
    gsap.from(".strip", {
      clipPath: "inset(0 100% 0 0)", duration: 1.1, ease: "power3.inOut", delay: 0.45
    });

    /* count-up statistik */
    document.querySelectorAll(".stat-num").forEach(function (el) {
      var target = parseInt(el.getAttribute("data-count"), 10);
      var obj = { v: 0 };
      gsap.to(obj, {
        v: target, duration: 1.6, ease: "power2.out",
        scrollTrigger: { trigger: el, start: "top 92%", once: true },
        onUpdate: function () { el.textContent = Math.round(obj.v); },
        onComplete: function () { el.textContent = target; }
      });
    });
    gsap.from(".hero-side", {
      opacity: 0, y: 34, duration: 0.9, ease: "power3.out", delay: 0.55
    });

    /* bab slider: pin + parallax ringan pada foto */
    gsap.fromTo(".ba",
      { scale: 0.965 },
      {
        scale: 1, ease: "none",
        scrollTrigger: {
          trigger: ".chapter-slider",
          start: "top top",
          end: "+=60%",
          pin: ".slider-pin",
          scrub: 0.4,
          anticipatePin: 1
        }
      }
    );
    gsap.from(".slider-text > *", {
      opacity: 0, x: -36, duration: 0.8, ease: "power3.out", stagger: 0.1,
      scrollTrigger: { trigger: ".chapter-slider", start: "top 65%", once: true }
    });

    /* judul bab: clip reveal */
    document.querySelectorAll(".chapter .chap-title").forEach(function (title) {
      gsap.from(title, {
        clipPath: "inset(0 0 100% 0)", y: 30, duration: 0.95, ease: "power3.out",
        scrollTrigger: { trigger: title, start: "top 85%", once: true }
      });
    });
    document.querySelectorAll(".chap-label").forEach(function (label) {
      gsap.from(label, {
        opacity: 0, x: -20, duration: 0.6, ease: "power2.out",
        scrollTrigger: { trigger: label, start: "top 88%", once: true }
      });
    });

    /* indeks kategori: stagger baris dari kiri */
    gsap.from(".idx-row", {
      opacity: 0, x: -44, duration: 0.65, ease: "power3.out", stagger: 0.07,
      scrollTrigger: { trigger: ".idx", start: "top 80%", once: true }
    });

    /* galeri: masuk per kelompok + parallax halus sebagian gambar */
    ScrollTrigger.batch(".g-item", {
      start: "top 92%",
      once: true,
      onEnter: function (batch) {
        gsap.from(batch, { opacity: 0, y: 44, duration: 0.7, ease: "power3.out", stagger: 0.06 });
      }
    });
    document.querySelectorAll(".g-item:nth-child(5n+2) img").forEach(function (img) {
      gsap.fromTo(img, { yPercent: -4 }, {
        yPercent: 4, ease: "none",
        scrollTrigger: { trigger: img.closest(".g-item"), start: "top bottom", end: "bottom top", scrub: 0.5 }
      });
    });

    /* cara order: nomor x-shift, teks menyusul */
    document.querySelectorAll(".step").forEach(function (step) {
      var tl = gsap.timeline({
        scrollTrigger: { trigger: step, start: "top 85%", once: true }
      });
      tl.from(step.querySelector(".step-num"), { x: -60, opacity: 0, duration: 0.7, ease: "power3.out" })
        .from(step.querySelector(".step-body"), { y: 30, opacity: 0, duration: 0.7, ease: "power3.out" }, "-=0.4");
    });

    /* faq: baris masuk bergantian */
    gsap.from(".faq-item", {
      opacity: 0, y: 26, duration: 0.6, ease: "power2.out", stagger: 0.09,
      scrollTrigger: { trigger: ".faq", start: "top 82%", once: true }
    });

    /* cta penutup: judul clip reveal */
    gsap.from(".cta-title", {
      clipPath: "inset(100% 0 0 0)", duration: 1, ease: "power3.out",
      scrollTrigger: { trigger: ".cta-final", start: "top 78%", once: true }
    });
  });
})();
