// liquid.js - Liquid Glass ala shuding/liquid-glass (SVG displacement shader).
// Peta displacement digambar dari SDF rounded-rect: tepi kaca menarik isi di
// belakangnya ke tengah (refraksi), tengahnya tetap. Diterapkan sebagai
// backdrop-filter url() pada lapisan kaca kosong. Peramban yang tidak
// mendukung url() pada backdrop-filter mengabaikan nilai inline ini dan
// jatuh ke blur CSS biasa.
// Lapisan kaca: elemen .lg-glass/.liquid-glass/.tab-glass langsung, plus
// mode host: semua pil dan kartu (HOST_SEL) diberi lapisan kaca anak oleh
// fungsi makeHost, kacanya terang atau gelap mengikuti warna dasar elemen.
(function () {
  'use strict';
  var uid = 0;
  var armed = [];
  var HOST_SEL = '.card, .btn, .chip, .pair-chip, .filters button, .src-badge, .jhero-clients, .svc-row, .stat, .needs-card, .dash-rows .r, .board-card, .dialog, .j-cta, .delta, .j-badge, .tab-badge, .dash-hero';

  function smooth01(t) {
    t = Math.max(0, Math.min(1, t));
    return t * t * (3 - 2 * t);
  }

  function buildMap(W, H, R) {
    var data = new Uint8ClampedArray(W * H * 4);
    var raw = new Float32Array(W * H * 2);
    var cx = W / 2, cy = H / 2;
    var band = Math.min(46, Math.min(W, H) * 0.5);
    var strength = 0.34;
    var maxD = 0.0001;
    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var px = x + 0.5 - cx, py = y + 0.5 - cy;
        var qx = Math.abs(px) - (cx - R), qy = Math.abs(py) - (cy - R);
        var ax = Math.max(qx, 0), ay = Math.max(qy, 0);
        var sdf = Math.min(Math.max(qx, qy), 0) + Math.sqrt(ax * ax + ay * ay) - R;
        var depth = -sdf;
        var edge = 1 - smooth01(depth / band);
        var pull = 1 - strength * edge;
        var dx = px * pull - px, dy = py * pull - py;
        var i = y * W + x;
        raw[i * 2] = dx; raw[i * 2 + 1] = dy;
        if (Math.abs(dx) > maxD) maxD = Math.abs(dx);
        if (Math.abs(dy) > maxD) maxD = Math.abs(dy);
      }
    }
    for (var j = 0; j < W * H; j++) {
      data[j * 4] = (raw[j * 2] / (2 * maxD) + 0.5) * 255;
      data[j * 4 + 1] = (raw[j * 2 + 1] / (2 * maxD) + 0.5) * 255;
      data[j * 4 + 2] = 0;
      data[j * 4 + 3] = 255;
    }
    return { data: data, scale: 2 * maxD };
  }

  function arm(el) {
    var W = el.clientWidth, H = el.clientHeight;
    if (!W || !H) return;
    var key = W + 'x' + H;
    if (el.getAttribute('data-lg-key') === key) return;
    var built = buildMap(W, H, Math.min(W, H) / 2);
    var canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    canvas.getContext('2d').putImageData(new ImageData(built.data, W, H), 0, 0);
    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '0'); svg.setAttribute('height', '0');
    svg.style.cssText = 'position:fixed;top:0;left:0;pointer-events:none;';
    svg.setAttribute('aria-hidden', 'true');
    var defs = document.createElementNS(NS, 'defs');
    var filter = document.createElementNS(NS, 'filter');
    var id = 'lgf-' + (++uid);
    filter.setAttribute('id', id);
    filter.setAttribute('filterUnits', 'userSpaceOnUse');
    filter.setAttribute('color-interpolation-filters', 'sRGB');
    filter.setAttribute('x', '0'); filter.setAttribute('y', '0');
    filter.setAttribute('width', String(W)); filter.setAttribute('height', String(H));
    var feImage = document.createElementNS(NS, 'feImage');
    feImage.setAttribute('width', String(W)); feImage.setAttribute('height', String(H));
    feImage.setAttribute('result', 'lgmap');
    feImage.setAttribute('href', canvas.toDataURL());
    var feDisp = document.createElementNS(NS, 'feDisplacementMap');
    feDisp.setAttribute('in', 'SourceGraphic');
    feDisp.setAttribute('in2', 'lgmap');
    feDisp.setAttribute('scale', built.scale.toFixed(2));
    feDisp.setAttribute('xChannelSelector', 'R');
    feDisp.setAttribute('yChannelSelector', 'G');
    filter.appendChild(feImage); filter.appendChild(feDisp);
    defs.appendChild(filter); svg.appendChild(defs);
    document.body.appendChild(svg);
    armed.push(svg);
    el.setAttribute('data-lg-key', key);
    el.style.backdropFilter = 'url(#' + id + ') blur(4px) saturate(1.4) brightness(1.03)';
    el.style.webkitBackdropFilter = el.style.backdropFilter;
  }

  function parseRGB(str) {
    var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(str || '');
    if (!m) return null;
    return { r: +m[1], g: +m[2], b: +m[3], a: m[4] === undefined ? 1 : +m[4] };
  }
  function lum(c) {
    function f(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }

  function makeHost(el) {
    if (el.classList.contains('lg-glass') || el.classList.contains('liquid-glass') || el.classList.contains('tab-glass')) return;
    if (el.querySelector(':scope > .lg-glass')) { arm(el.querySelector(':scope > .lg-glass')); return; }
    var cs = getComputedStyle(el);
    var bg = parseRGB(cs.backgroundColor);
    var fg = parseRGB(cs.color);
    var dark;
    if (bg && bg.a >= 0.15) dark = lum(bg) < 0.45;
    else dark = fg ? lum(fg) > 0.6 : false;
    var span = document.createElement('span');
    span.className = 'lg-glass' + (dark ? '' : ' lg-light');
    span.setAttribute('aria-hidden', 'true');
    el.classList.add('lg-host');
    el.insertBefore(span, el.firstChild);
    arm(span);
  }

  function armAll() {
    var direct = document.querySelectorAll('.liquid-glass, .tab-glass, .lg-glass');
    for (var i = 0; i < direct.length; i++) {
      if (!direct[i].parentElement || !direct[i].parentElement.classList.contains('lg-host')) arm(direct[i]);
    }
    var hosts = document.querySelectorAll(HOST_SEL);
    for (var j = 0; j < hosts.length; j++) makeHost(hosts[j]);
  }

  function cleanup() {
    for (var i = 0; i < armed.length; i++) armed[i].remove();
    armed = [];
    var els = document.querySelectorAll('[data-lg-key]');
    for (var j = 0; j < els.length; j++) els[j].removeAttribute('data-lg-key');
  }

  var timer = null;
  function schedule() {
    if (timer) clearTimeout(timer);
    timer = setTimeout(function () { cleanup(); armAll(); }, 180);
  }

  function init() {
    armAll();
    var app = document.getElementById('app');
    if (app && window.MutationObserver) {
      new MutationObserver(schedule).observe(app, { childList: true });
    }
    window.addEventListener('resize', schedule);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
