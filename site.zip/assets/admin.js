// admin.js · dashboard admin FNATIX ID (bagian 1: shell, dashboard, pesanan).
(function () {
  const { esc, rp, rpOrDash, waLink, fmtDate, todayISO, monthStartISO, slugify, validHttpUrl, parseMoney, downloadCsv, uid } = window.U;
  const ORDER_STATUSES = ['Antrean', 'Dikerjakan', 'Menunggu Respons', 'Revisi', 'Selesai', 'Dibatalkan'];
  const ACTIVE_STATUSES = ['Antrean', 'Dikerjakan', 'Menunggu Respons', 'Revisi'];

  let S = null; // state admin

  function toast(msg, isErr) {
    const t = document.createElement('div');
    t.className = 'toast' + (isErr ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3400);
  }

  function dialog(title, bodyHtml, wide) {
    const ov = document.createElement('div');
    ov.className = 'overlay';
    ov.innerHTML = '<div class="dialog' + (wide ? ' wide' : '') + '" role="dialog" aria-modal="true">' +
      '<div class="dialog-head"><h3 style="margin:0">' + esc(title) + '</h3>' +
      '<button type="button" class="btn ghost small x" data-close>Tutup</button></div>' + bodyHtml + '</div>';
    document.body.appendChild(ov);
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    ov.addEventListener('click', function (e) { if (e.target === ov || (e.target.hasAttribute && e.target.hasAttribute('data-close'))) close(); });
    return { el: ov, close };
  }

  function confirmDialog(text) {
    return new Promise(function (resolve) {
      const d = dialog('Konfirmasi', '<p>' + esc(text) + '</p><div class="btn-row">' +
        '<button class="btn danger" id="cf-yes">Ya, lanjutkan</button>' +
        '<button class="btn ghost" data-close>Batal</button></div>');
      d.el.querySelector('#cf-yes').addEventListener('click', function () { d.close(); resolve(true); });
      d.el.addEventListener('click', function (e) { if (e.target === d.el) resolve(false); });
      const x = d.el.querySelector('[data-close]');
      if (x) x.addEventListener('click', function () { resolve(false); });
    });
  }

  function field(label, inner, hint) {
    return '<div class="field"><label>' + esc(label) + '</label>' + inner + (hint ? '<div class="hint">' + esc(hint) + '</div>' : '') + '</div>';
  }
  function input(name, val, attrs) {
    return '<input name="' + name + '" value="' + esc(val === null || val === undefined ? '' : val) + '" ' + (attrs || '') + '>';
  }
  function textarea(name, val, attrs) {
    return '<textarea name="' + name + '" ' + (attrs || '') + '>' + esc(val || '') + '</textarea>';
  }
  function selectHtml(name, options, val) {
    return '<select name="' + name + '">' + options.map(function (o) {
      const v = Array.isArray(o) ? o[0] : o, t = Array.isArray(o) ? o[1] : o;
      return '<option value="' + esc(v) + '"' + (String(v) === String(val) ? ' selected' : '') + '>' + esc(t) + '</option>';
    }).join('') + '</select>';
  }
  function formData(form) {
    const o = {};
    new FormData(form).forEach(function (v, k) { o[k] = v; });
    return o;
  }
  async function handle(form, fn) {
    const btn = form.querySelector('[type=submit]');
    if (btn) { btn.disabled = true; btn.textContent = 'Menyimpan…'; }
    try { await fn(formData(form)); return true; }
    catch (e) { toast(e.message || 'Gagal menyimpan.', true); if (btn) { btn.disabled = false; btn.textContent = 'Simpan'; } return false; }
  }

  // ---------- perhitungan pembayaran ----------
  function paymentsOf(orderId) { return S.payments.filter(p => p.order_id === orderId); }
  function refundsOfPayment(pid) { return S.refunds.filter(r => r.payment_id === pid); }
  function orderPaidNet(orderId) {
    return paymentsOf(orderId).reduce(function (sum, p) {
      const ref = refundsOfPayment(p.id).reduce((a, r) => a + Number(r.amount), 0);
      return sum + Number(p.amount) - ref;
    }, 0);
  }
  function orderPaidGross(orderId) {
    return paymentsOf(orderId).reduce((a, p) => a + Number(p.amount), 0);
  }
  function orderTotal(o) { return Number(o.total_price || 0) - Number(o.discount || 0); }
  function orderPayStatus(o) {
    const paid = orderPaidNet(o.id);
    const total = orderTotal(o);
    if (paid <= 0) return 'Belum Bayar';
    if (paid < total) return 'DP';
    return 'Lunas';
  }
  function salePaidNet(saleId) {
    return S.payments.filter(p => p.digital_sale_id === saleId).reduce(function (sum, p) {
      const ref = refundsOfPayment(p.id).reduce((a, r) => a + Number(r.amount), 0);
      return sum + Number(p.amount) - ref;
    }, 0);
  }
  function saleTotal(s) { return Number(s.price_snapshot || 0) * Number(s.qty || 1) - Number(s.discount || 0); }
  function salePayStatus(s) {
    const paid = salePaidNet(s.id);
    if (paid <= 0) return 'Belum Bayar';
    if (paid < saleTotal(s)) return 'Sebagian';
    return 'Lunas';
  }

  async function loadAll() {
    const q = 'select=*&order=created_at.desc';
    const [settings, categories, services, portfolio, products, testimonials, orders, revisions, sales, payments, refunds, expenses] =
      await Promise.all([
        DB.select('studio_settings', 'select=*&id=eq.1'),
        DB.select('studio_categories', 'select=*&order=sort_order.asc'),
        DB.select('studio_services', 'select=*&order=sort_order.asc'),
        DB.select('studio_portfolio_items', 'select=*&order=sort_order.asc'),
        DB.select('studio_products', 'select=*&order=sort_order.asc'),
        DB.select('studio_testimonials', 'select=*&order=sort_order.asc'),
        DB.select('studio_orders', q),
        DB.select('studio_order_revisions', 'select=*&order=rev_date.asc'),
        DB.select('studio_digital_sales', q),
        DB.select('studio_payments', 'select=*&order=pay_date.asc'),
        DB.select('studio_refunds', 'select=*&order=refund_date.asc'),
        DB.select('studio_expenses', 'select=*&order=expense_date.desc')
      ]);
    S = {
      settings: settings[0] || {},
      categories, services, portfolio, products, testimonials,
      orders, revisions, sales, payments, refunds, expenses
    };
    return S;
  }

  const IC = {
    grid: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/></svg>',
    clip: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="5" y="4.5" width="14" height="16.5" rx="2"/><path d="M9 4.5a3 3 0 0 1 6 0"/><path d="M9 11.5h6M9 15.5h4"/></svg>',
    img: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.6" cy="10" r="1.6"/><path d="M21 15.5 16 10.5l-9.5 9.5"/></svg>',
    layers: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5 21 8.5l-9 5-9-5 9-5z"/><path d="M3.6 13.4 12 18l8.4-4.6"/></svg>',
    bag: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.8 8h14.4l-1.1 11.2a2 2 0 0 1-2 1.8H7.9a2 2 0 0 1-2-1.8L4.8 8z"/><path d="M8.5 10.5v-4a3.5 3.5 0 0 1 7 0v4"/></svg>',
    chart: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 20v-6M12 20V5M18 20v-9"/><path d="M3.5 20h17"/></svg>',
    wallet: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3.5 7.5A2.5 2.5 0 0 1 6 5h12.5a1 1 0 0 1 1 1v2"/><rect x="3" y="7" width="18" height="12" rx="2.5"/><circle cx="16.6" cy="13" r="1.3" fill="currentColor" stroke="none"/></svg>',
    star: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3.8l2.5 5.2 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8L12 3.8z"/></svg>',
    sliders: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h9M17 7h3M4 17h3M11 17h9M4 12h13"/><circle cx="15" cy="7" r="2.1"/><circle cx="9" cy="17" r="2.1"/><circle cx="19" cy="12" r="2.1"/></svg>',
    search: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M16.3 16.3 20.5 20.5"/></svg>',
    out: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 20.5H6.5a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2H9"/><path d="M15.5 16.5 20 12l-4.5-4.5"/><path d="M20 12H9.5"/></svg>',
    ext: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4.5h5.5V10"/><path d="M19.5 4.5 11 13"/><path d="M19.5 14.5v4a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18.5v-12A1.5 1.5 0 0 1 6 5h4.5"/></svg>'
  };
  function rpShort(v) {
    v = Number(v || 0);
    if (v >= 1000000) return 'Rp' + (Math.round(v / 100000) / 10).toString().replace('.', ',') + ' jt';
    if (v >= 1000) return 'Rp' + Math.round(v / 1000) + ' rb';
    return rp(v);
  }
  function shell(active, title, bodyHtml) {
    const tz = S.settings.timezone || 'Asia/Jakarta';
    const today = todayISO(tz);
    const nav = [
      ['/admin', 'Dashboard', 'grid', 0], ['/admin/pesanan', 'Pesanan', 'clip', 0], ['/admin/portofolio', 'Portofolio', 'img', S.portfolio.length],
      ['/admin/layanan', 'Layanan', 'layers', 0], ['/admin/produk', 'Produk', 'bag', S.products.length], ['/admin/penjualan', 'Penjualan', 'chart', 0],
      ['/admin/keuangan', 'Keuangan', 'wallet', 0], ['/admin/testimoni', 'Testimoni', 'star', 0], ['/admin/pengaturan', 'Pengaturan', 'sliders', 0]
    ];
    const actCount = S.orders.filter(o => ACTIVE_STATUSES.includes(o.status)).length;
    const odCount = S.orders.filter(o => o.deadline && o.deadline < today && ACTIVE_STATUSES.includes(o.status)).length;
    const myName = (S.profile && (S.profile.name || S.profile.display_name)) || 'Fnatyx';
    const hour = Number(new Date().toLocaleString('en-US', { timeZone: tz, hour: 'numeric', hour12: false }));
    const greet = (hour >= 19 || hour < 4) ? 'Selamat malam' : hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : 'Selamat sore';
    const top = '<div class="j-topwrap"><header class="j-top"><span class="lg-glass" aria-hidden="true"></span>' +
      '<a class="j-brand" href="/admin"><img src="/fnatix-porto/demo/logo-fnatix.png" alt="Logo FNATIX ID">fnatix.id</a>' +
      '<nav class="j-nav">' + nav.map(function (n) {
        let badge = '';
        if (n[0] === '/admin/pesanan' && actCount) badge = '<span class="j-badge">' + actCount + '</span>';
        else if (n[3]) badge = '<span class="j-badge">' + n[3] + '</span>';
        return '<a href="' + n[0] + '" class="' + (active === n[0] ? 'active' : '') + '">' + IC[n[2]] + '<span>' + n[1] + '</span>' + badge + '</a>';
      }).join('') + '</nav>' +
      '<a class="j-cta" href="/">Lihat Situs</a>' +
      '</header></div>';
    const dateLine = new Date(today + 'T12:00:00').toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: tz });
    const sub = '<div class="j-sub">' +
      '<form class="j-search" id="side-search" role="search">' + IC.search + '<input name="q" type="search" placeholder="Cari pesanan..." aria-label="Cari pesanan"></form>' +
      '<span class="j-user"><span class="ava">' + esc(myName.trim().charAt(0).toUpperCase()) + '</span><span class="j-user-tx"><b>' + esc(myName) + '</b><span>Pemilik</span></span><a href="#" class="j-out" data-logout>Keluar</a></span>' +
      '</div>';
    const head = '<div class="j-head"><p class="j-date">' + esc(dateLine) + (title !== 'Dashboard' ? ' · ' + esc(title) : '') + '</p>' +
      '<h1 class="j-big">' + greet + ', ' + esc(myName) + '.</h1>' +
      (odCount ? '<p class="j-meta">Ada <b>' + odCount + ' pesanan terlewat</b> yang menunggu ditindaklanjuti.</p>' : '') +
      '<a class="j-new" href="/admin/pesanan?baru=1">+ Pesanan Baru</a></div>';
    const morePaths = ['/admin/layanan', '/admin/produk', '/admin/keuangan', '/admin/testimoni', '/admin/pengaturan'];
    const tabItem = (href, icon, label, badge) =>
      '<a href="' + href + '" class="tab-item' + (active === href ? ' active' : '') + '"><span class="tab-ic">' + IC[icon] + (badge ? '<span class="tab-badge">' + badge + '</span>' : '') + '</span><span>' + label + '</span></a>';
    const tabbar = '<div class="tab-glass" aria-hidden="true"></div>' +
      '<nav class="tabbar">' +
      tabItem('/admin', 'grid', 'Dashboard', 0) +
      tabItem('/admin/pesanan', 'clip', 'Pesanan', actCount || 0) +
      tabItem('/admin/portofolio', 'img', 'Portofolio', 0) +
      tabItem('/admin/penjualan', 'chart', 'Penjualan', 0) +
      '<button type="button" class="tab-item' + (morePaths.includes(active) ? ' active' : '') + '" id="tab-more" aria-haspopup="true"><span class="tab-ic">' + IC.sliders + '</span><span>Lainnya</span></button></nav>';
    const sheetRow = (href, icon, label, count) =>
      '<a href="' + href + '" class="sheet-row' + (active === href ? ' active' : '') + '">' + IC[icon] + '<span>' + label + '</span>' + (count ? '<span class="nav-count">' + count + '</span>' : '') + '</a>';
    const sheet = '<div class="more-sheet" id="more-sheet" hidden><div class="sheet-backdrop" data-close-sheet></div><div class="sheet-panel">' +
      '<div class="side-label" style="display:block;padding-top:2px">Menu Lainnya</div>' +
      sheetRow('/admin/layanan', 'layers', 'Layanan', 0) +
      sheetRow('/admin/produk', 'bag', 'Produk', S.products.length || 0) +
      sheetRow('/admin/keuangan', 'wallet', 'Keuangan', 0) +
      sheetRow('/admin/testimoni', 'star', 'Testimoni', 0) +
      sheetRow('/admin/pengaturan', 'sliders', 'Pengaturan', 0) +
      '<a href="/" class="sheet-row">' + IC.ext + '<span>Lihat Situs Publik</span></a>' +
      '<div class="user-card"><span class="ava">' + esc(myName.trim().charAt(0).toUpperCase()) + '</span>' +
      '<div><div class="uc-name">' + esc(myName) + '</div><div class="uc-role">Pemilik</div></div>' +
      '<a href="#" class="uc-out" data-logout>Keluar</a></div>' +
      '</div></div>';
    return '<div class="admin-shell">' + top + '<main class="admin-main">' + sub + head + bodyHtml + '</main>' + tabbar + sheet + '</div>';
  }
  function mountShell(root) {
    root.querySelectorAll('[data-logout]').forEach(function (el) {
      el.addEventListener('click', async function (e) {
        e.preventDefault();
        await DB.signOut();
        location.href = (window.FNATIX_BASE || '') + '/admin/login';
      });
    });
    const sf = root.querySelector('#side-search');
    if (sf) sf.addEventListener('submit', function (e) {
      e.preventDefault();
      const q = sf.querySelector('input[name="q"]').value.trim();
      location.href = '/admin/pesanan' + (q ? '?q=' + encodeURIComponent(q) : '');
    });
    const moreBtn = root.querySelector('#tab-more');
    const sheet = root.querySelector('#more-sheet');
    if (moreBtn && sheet) {
      moreBtn.addEventListener('click', function () { sheet.hidden = !sheet.hidden; });
      sheet.querySelectorAll('[data-close-sheet]').forEach(function (el) {
        el.addEventListener('click', function () { sheet.hidden = true; });
      });
    }
  }

  // ---------- Login ----------
  function loginPage() {
    return '<main><section class="block"><div class="wrap" style="max-width:440px">' +
      '<h1>Login Admin</h1><p class="muted">Area khusus pemilik FNATIX ID.</p>' +
      '<form id="login-form" method="post"><div class="field"><label>Email</label><input name="email" type="email" required autocomplete="username"></div>' +
      '<div class="field"><label>Kata Sandi</label><input name="password" type="password" required autocomplete="current-password"></div>' +
      '<button class="btn" type="submit" style="width:100%">Masuk</button>' +
      '<p class="err" id="login-err" style="color:var(--bad);margin-top:10px"></p></form>' +
      '<p class="small muted" style="margin-top:14px"><a href="/">Kembali ke beranda</a></p>' +
      '</div></section></main>';
  }
  function mountLogin(root) {
    const form = root.querySelector('#login-form');
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      const d = formData(form);
      const err = root.querySelector('#login-err');
      err.textContent = '';
      try {
        await DB.signIn(d.email.trim(), d.password);
        location.href = (window.FNATIX_BASE || '') + '/admin';
      } catch (ex) { err.textContent = 'Login gagal: ' + (ex.message || 'periksa email dan kata sandi.'); }
    });
  }

  // ---------- Dashboard ----------
  function dashboardPage() {
    const tz = S.settings.timezone || 'Asia/Jakarta';
    const today = todayISO(tz);
    const mStart = monthStartISO(tz);
    const active = S.orders.filter(o => ACTIVE_STATUSES.includes(o.status));
    const dueToday = S.orders.filter(o => o.deadline === today && ACTIVE_STATUSES.includes(o.status));
    const overdue = S.orders.filter(o => o.deadline && o.deadline < today && ACTIVE_STATUSES.includes(o.status));
    const inRevision = S.orders.filter(o => o.status === 'Revisi');
    let piutang = 0;
    S.orders.forEach(o => {
      if (o.status !== 'Dibatalkan') {
        const sisa = orderTotal(o) - orderPaidNet(o.id);
        if (sisa > 0) piutang += sisa;
      }
    });
    S.sales.forEach(s => {
      const sisa = saleTotal(s) - salePaidNet(s.id);
      if (sisa > 0) piutang += sisa;
    });
    const incomeMonth = S.payments.filter(p => p.pay_date >= mStart).reduce((a, p) => a + Number(p.amount), 0)
      - S.refunds.filter(r => r.refund_date >= mStart).reduce((a, r) => a + Number(r.amount), 0);
    const expenseMonth = S.expenses.filter(e => e.expense_date >= mStart).reduce((a, e) => a + Number(e.amount), 0);
    const pmDate = new Date(mStart + 'T12:00:00Z'); pmDate.setUTCMonth(pmDate.getUTCMonth() - 1);
    const pmStart = pmDate.toISOString().slice(0, 10);
    const incomePrev = S.payments.filter(p => p.pay_date >= pmStart && p.pay_date < mStart).reduce((a, p) => a + Number(p.amount), 0)
      - S.refunds.filter(r => r.refund_date >= pmStart && r.refund_date < mStart).reduce((a, r) => a + Number(r.amount), 0);
    const payCount = S.payments.filter(p => p.pay_date >= mStart).length;
    const monthName = new Date(mStart + 'T12:00:00').toLocaleDateString('id-ID', { month: 'long', year: 'numeric', timeZone: tz });
    let deltaHtml = '';
    if (incomePrev > 0) {
      const pct = Math.round((incomeMonth - incomePrev) / incomePrev * 100);
      deltaHtml = '<span class="delta ' + (pct >= 0 ? 'up' : 'down') + '">' + (pct >= 0 ? '▲' : '▼') + ' ' + Math.abs(pct) + '% vs bulan lalu</span>';
    }
    const upcoming = active.slice().sort(function (a, b) {
      if (!a.deadline && !b.deadline) return 0;
      if (!a.deadline) return 1;
      if (!b.deadline) return -1;
      return a.deadline < b.deadline ? -1 : 1;
    }).slice(0, 8);
    const svcName = id => { const s = S.services.find(x => x.id === id); return s ? s.name : ''; };
    const row = (k, v, cls) => '<div class="r"><span>' + k + '</span><b class="' + (cls || '') + '">' + v + '</b></div>';
    let h = '<div class="dash-hero">' +
      '<div class="lab"><span>Uang masuk · ' + esc(monthName) + '</span>' + deltaHtml + '</div>' +
      '<div class="big">' + rp(incomeMonth) + '</div>' +
      '<div class="muted small">Dari ' + payCount + ' pembayaran tercatat bulan ini, setelah refund.</div>' +
      '<div class="dash-rows">' +
      row('Pesanan aktif', active.length) +
      row('Deadline hari ini', dueToday.length) +
      row('Terlewat', overdue.length, overdue.length ? 'bad-t' : '') +
      row('Sedang revisi', inRevision.length) +
      row('Piutang (sisa tagihan)', rp(piutang)) +
      row('Pengeluaran bulan ini', rp(expenseMonth)) +
      '</div></div>';
    if (overdue.length || dueToday.length) {
      const parts = [];
      if (overdue.length) parts.push(overdue.length + ' pesanan terlewat deadline');
      if (dueToday.length) parts.push(dueToday.length + ' deadline hari ini');
      h += '<div class="dash-alert"><span>' + parts.join(' dan ') + '. Segera tindaklanjuti supaya pelanggan tidak menunggu.</span>' +
        '<a class="btn small" href="/admin/pesanan?deadline=' + (overdue.length ? 'terlewat' : 'hari-ini') + '">Lihat Pesanan</a></div>';
    }
    const needs = S.orders.filter(function (o) {
      if (o.status === 'Dibatalkan') return false;
      const sisa = orderTotal(o) - orderPaidNet(o.id);
      return (o.deadline && o.deadline < today && ACTIVE_STATUSES.includes(o.status)) ||
        (o.deadline === today && ACTIVE_STATUSES.includes(o.status)) ||
        o.status === 'Revisi' || (o.status === 'Selesai' && sisa > 0);
    }).sort(function (a, b) {
      const rank = o => (o.deadline && o.deadline < today && ACTIVE_STATUSES.includes(o.status)) ? 0 : (o.deadline === today ? 1 : (o.status === 'Revisi' ? 2 : 3));
      return rank(a) - rank(b);
    }).slice(0, 5);
    h += '<div class="admin-top"><h2 style="margin:0">Perlu Perhatian</h2>' + (needs.length ? '<span class="nav-count hot" style="margin-left:10px">' + needs.length + '</span>' : '') + '<span class="spacer"></span>' +
      '<a class="btn ghost small" href="/admin/pesanan">Semua Pesanan</a></div>';
    if (!needs.length) h += '<div class="empty">Tidak ada yang menunggu tindakan. Semua pesanan aman.</div>';
    else h += needs.map(function (o) {
      const sisa = orderTotal(o) - orderPaidNet(o.id);
      const od = o.deadline && o.deadline < today && ACTIVE_STATUSES.includes(o.status);
      const why = od ? 'Terlewat · deadline ' + fmtDate(o.deadline, tz) : (o.deadline === today ? 'Deadline hari ini' : (o.status === 'Revisi' ? 'Sedang revisi' : 'Selesai, menunggu pembayaran'));
      return '<div class="needs-card"><div class="nc-main"><div class="nc-name">' + esc(o.customer_name) + '</div>' +
        '<div class="muted small">' + esc(svcName(o.service_id) || 'Pesanan') + ' · ' + esc(o.status) + ' · ' + why + '</div></div>' +
        '<span class="spacer"></span>' + (sisa > 0 ? '<span class="nc-sisa">' + rp(sisa) + '</span>' : '') +
        '<a class="btn small" href="/admin/pesanan/' + o.id + '">Buka</a></div>';
    }).join('');
    h += '<div class="admin-top"><h2 style="margin:0">Pekerjaan Terdekat</h2><span class="spacer"></span>' +
      '<a class="btn" href="/admin/pesanan?baru=1">Tambah Pesanan</a></div>';
    if (!upcoming.length) h += '<div class="empty">Tidak ada pesanan aktif. Klik Tambah Pesanan setelah menerima order via chat.</div>';
    else {
      h += '<div class="table-wrap"><table><thead><tr><th>Kode</th><th>Pelanggan</th><th>Status</th><th>Deadline</th><th class="num">Sisa</th></tr></thead><tbody>' +
        upcoming.map(function (o) {
          const sisa = orderTotal(o) - orderPaidNet(o.id);
          const dl = o.deadline ? (o.deadline < today ? '<span class="chip bad">Terlewat ' + fmtDate(o.deadline, tz) + '</span>' : fmtDate(o.deadline, tz)) : '–';
          return '<tr><td><a href="/admin/pesanan/' + o.id + '">' + esc(o.code || '') + '</a></td><td><span class="ava">' + esc((o.customer_name || '?').trim().charAt(0).toUpperCase()) + '</span>' + esc(o.customer_name) + '</td>' +
            '<td><span class="chip">' + esc(o.status) + '</span></td><td>' + dl + '</td><td class="num">' + (sisa > 0 ? rp(sisa) : '–') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    return { html: shell('/admin', 'Dashboard', h), mount: mountShell };
  }

  // ---------- Pesanan: daftar + papan ----------
  function payChip(o) {
    const st = orderPayStatus(o);
    const cls = st === 'Lunas' ? 'ok' : (st === 'DP' ? 'warn' : 'bad');
    return '<span class="chip ' + cls + '">' + st + '</span>';
  }
  function ordersPage(query) {
    const tz = S.settings.timezone || 'Asia/Jakarta';
    const fStatus = query.get('status') || '';
    const fPay = query.get('bayar') || '';
    const fSvc = query.get('layanan') || '';
    const fDue = query.get('deadline') || '';
    const q = (query.get('q') || '').toLowerCase();
    const view = query.get('tampilan') || 'daftar';
    let items = S.orders.slice();
    if (fStatus) items = items.filter(o => o.status === fStatus);
    if (fPay) items = items.filter(o => orderPayStatus(o) === fPay);
    if (fSvc) items = items.filter(o => o.service_id === fSvc);
    if (fDue === 'hari-ini') items = items.filter(o => o.deadline === todayISO(tz));
    if (fDue === 'terlewat') items = items.filter(o => o.deadline && o.deadline < todayISO(tz) && ACTIVE_STATUSES.includes(o.status));
    if (q) items = items.filter(o => (o.customer_name || '').toLowerCase().includes(q) || (o.code || '').toLowerCase().includes(q));
    items.sort(function (a, b) {
      if (!a.deadline && !b.deadline) return 0;
      if (!a.deadline) return 1;
      if (!b.deadline) return -1;
      return a.deadline < b.deadline ? -1 : 1;
    });

    let h = '<form method="get" action="/admin/pesanan" class="form-grid two get-filter" style="margin-bottom:14px">' +
      field('Cari nama / kode', '<input name="q" value="' + esc(query.get('q') || '') + '" placeholder="cth: FX-2026 atau nama pelanggan">') +
      field('Status', selectHtml('status', [''].concat(ORDER_STATUSES).map(s => [s, s || 'Semua status']), fStatus)) +
      field('Pembayaran', selectHtml('bayar', [['', 'Semua'], ['Belum Bayar', 'Belum Bayar'], ['DP', 'DP'], ['Lunas', 'Lunas']], fPay)) +
      field('Layanan', selectHtml('layanan', [['', 'Semua layanan']].concat(S.services.map(s => [s.id, s.name])), fSvc)) +
      field('Deadline', selectHtml('deadline', [['', 'Semua'], ['hari-ini', 'Hari ini'], ['terlewat', 'Terlewat']], fDue)) +
      field('Tampilan', selectHtml('tampilan', [['daftar', 'Daftar'], ['papan', 'Papan kerja']], view)) +
      '<div class="field"><label>&nbsp;</label><button class="btn secondary" type="submit">Terapkan Filter</button></div></form>' +
      '<div class="admin-top"><span class="muted">' + items.length + ' pesanan</span><span class="spacer"></span>' +
      '<button class="btn" id="btn-order-new">Tambah Pesanan</button> ' +
      '<button class="btn ghost" id="btn-order-csv">Ekspor CSV</button></div>';

    if (view === 'papan') {
      h += '<div class="board">' + ORDER_STATUSES.map(function (st) {
        const col = items.filter(o => o.status === st);
        return '<div class="board-col"><h3>' + st + ' (' + col.length + ')</h3>' +
          col.map(function (o) {
            return '<div class="board-card"><a href="/admin/pesanan/' + o.id + '">' + esc(o.code || '') + ' · ' + esc(o.customer_name) + '</a>' +
              '<div class="small muted">' + (o.deadline ? 'Deadline ' + fmtDate(o.deadline, tz) : 'Tanpa deadline') + ' · ' + orderPayStatus(o) + '</div>' +
              '<select data-status-for="' + o.id + '" aria-label="Ubah status ' + esc(o.code || '') + '">' +
              ORDER_STATUSES.map(s2 => '<option value="' + s2 + '"' + (s2 === o.status ? ' selected' : '') + '>' + s2 + '</option>').join('') + '</select></div>';
          }).join('') + '</div>';
      }).join('') + '</div>';
    } else if (!items.length) {
      h += '<div class="empty">Tidak ada pesanan yang cocok dengan filter.</div>';
    } else {
      h += '<div class="table-wrap"><table><thead><tr><th>Kode</th><th>Pelanggan</th><th>Layanan</th><th>Status</th><th>Bayar</th><th>Deadline</th><th class="num">Total</th><th class="num">Sisa</th></tr></thead><tbody>' +
        items.map(function (o) {
          const svc = S.services.find(s => s.id === o.service_id);
          const sisa = orderTotal(o) - orderPaidNet(o.id);
          return '<tr><td><a href="/admin/pesanan/' + o.id + '">' + esc(o.code || '') + '</a></td>' +
            '<td>' + esc(o.customer_name) + '</td><td>' + esc(svc ? svc.name : (o.service_name_snapshot || '–')) + '</td>' +
            '<td><span class="chip">' + esc(o.status) + '</span></td><td>' + payChip(o) + '</td>' +
            '<td>' + (o.deadline ? fmtDate(o.deadline, tz) : '–') + '</td>' +
            '<td class="num">' + rp(orderTotal(o)) + '</td><td class="num">' + (sisa > 0 ? rp(sisa) : '–') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    return {
      html: shell('/admin/pesanan', 'Pesanan Jasa Edit', h),
      mount: function (root) {
        mountShell(root);
        root.querySelector('#btn-order-new').addEventListener('click', function () { orderFormDialog(null); });
        if (query.get('baru') === '1') orderFormDialog(null);
        root.querySelector('#btn-order-csv').addEventListener('click', function () {
          const rows = [['Kode', 'Pelanggan', 'WhatsApp', 'Sumber', 'Layanan', 'Status', 'Status Bayar', 'Tanggal Masuk', 'Deadline', 'Total', 'Diskon', 'Terbayar', 'Sisa']];
          S.orders.forEach(function (o) {
            const svc = S.services.find(s => s.id === o.service_id);
            rows.push([o.code || '', o.customer_name, o.customer_wa || '', o.source, svc ? svc.name : (o.service_name_snapshot || ''), o.status, orderPayStatus(o), o.received_at || '', o.deadline || '', orderTotal(o), Number(o.discount || 0), orderPaidNet(o.id), orderTotal(o) - orderPaidNet(o.id)]);
          });
          downloadCsv('pesanan-fnatix.csv', rows);
        });
        root.querySelectorAll('[data-status-for]').forEach(function (sel) {
          sel.addEventListener('change', async function () {
            try {
              await DB.update('studio_orders', sel.getAttribute('data-status-for'), { status: sel.value, updated_at: new Date().toISOString() });
              toast('Status diperbarui.');
              await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
            } catch (e) { toast(e.message, true); }
          });
        });
      }
    };
  }

  function orderFormDialog(existing) {
    const o = existing || {};
    const d = dialog(existing ? 'Edit Pesanan' : 'Tambah Pesanan',
      '<form id="order-form"><div class="form-grid two">' +
      field('Nama pelanggan *', input('customer_name', o.customer_name, 'required')) +
      field('Nomor WhatsApp', input('customer_wa', o.customer_wa, 'placeholder="08xx"')) +
      field('Sumber order', selectHtml('source', ['WhatsApp', 'Instagram', 'Lainnya'], o.source || 'WhatsApp')) +
      field('Layanan', selectHtml('service_id', [['', 'Pilih layanan atau isi manual']].concat(S.services.map(s => [s.id, s.name])), o.service_id || '')) +
      field('Nama layanan (manual, bila tidak memilih)', input('service_name_snapshot', o.service_name_snapshot)) +
      field('Tanggal masuk', input('received_at', o.received_at || todayISO(S.settings.timezone), 'type="date"')) +
      field('Deadline', input('deadline', o.deadline || '', 'type="date"')) +
      field('Prioritas', selectHtml('priority', ['Rendah', 'Normal', 'Tinggi'], o.priority || 'Normal')) +
      field('Status', selectHtml('status', ORDER_STATUSES, o.status || 'Antrean')) +
      field('Total harga (Rp)', input('total_price', o.total_price !== undefined ? o.total_price : '', 'type="number" min="0" step="1"')) +
      field('Diskon nominal (Rp)', input('discount', o.discount || 0, 'type="number" min="0" step="1"')) +
      field('Batas revisi', input('revision_limit', o.revision_limit || 0, 'type="number" min="0" step="1"')) +
      '</div>' +
      field('Ringkasan kebutuhan', textarea('needs_summary', o.needs_summary)) +
      field('Instruksi terperinci', textarea('instructions', o.instructions)) +
      field('Catatan internal (privat)', textarea('internal_notes', o.internal_notes)) +
      '<button class="btn" type="submit">Simpan</button></form>', true);
    const form = d.el.querySelector('#order-form');
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      const ok = await handle(form, async function (data) {
        const row = {
          customer_name: data.customer_name.trim(),
          customer_wa: data.customer_wa || '',
          source: data.source,
          service_id: data.service_id || null,
          service_name_snapshot: data.service_name_snapshot || '',
          received_at: data.received_at || todayISO(S.settings.timezone),
          deadline: data.deadline || null,
          priority: data.priority,
          status: data.status,
          total_price: parseMoney(data.total_price) || 0,
          discount: parseMoney(data.discount) || 0,
          revision_limit: parseInt(data.revision_limit || '0', 10) || 0,
          needs_summary: data.needs_summary || '',
          instructions: data.instructions || '',
          internal_notes: data.internal_notes || '',
          updated_at: new Date().toISOString()
        };
        if (existing) await DB.update('studio_orders', existing.id, row);
        else await DB.insert('studio_orders', row);
        toast('Pesanan tersimpan.');
        d.close();
        await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
      });
      return ok;
    });
  }

  // ---------- Detail pesanan ----------
  function orderDetailPage(id) {
    const o = S.orders.find(x => x.id === id);
    if (!o) return null;
    const tz = S.settings.timezone || 'Asia/Jakarta';
    const svc = S.services.find(s => s.id === o.service_id);
    const revs = S.revisions.filter(r => r.order_id === o.id);
    const pays = paymentsOf(o.id);
    const total = orderTotal(o);
    const paidNet = orderPaidNet(o.id);
    const sisa = total - paidNet;
    const atts = Array.isArray(o.attachments) ? o.attachments : [];
    const wa = waLink(o.customer_wa, 'Halo ' + o.customer_name + ', terkait pesanan ' + (o.code || '') + ' di FNATIX ID.');
    let h = '<p><a href="/admin/pesanan">&larr; Semua pesanan</a></p>' +
      '<div class="stat-grid" style="grid-template-columns:repeat(2,1fr)">' +
      '<div class="stat"><div class="v">' + rp(total) + '</div><div class="k">Nilai pesanan (setelah diskon)</div></div>' +
      '<div class="stat"><div class="v">' + rp(paidNet) + '</div><div class="k">Uang diterima (bersih refund)</div></div>' +
      '<div class="stat"><div class="v">' + (sisa > 0 ? rp(sisa) : rp(0)) + '</div><div class="k">Sisa tagihan · status ' + orderPayStatus(o) + '</div></div>' +
      '<div class="stat"><div class="v">' + revs.length + ' / ' + (o.revision_limit || 0) + '</div><div class="k">Revisi terpakai / batas</div></div></div>' +
      '<div class="card" style="margin-bottom:16px"><div class="card-body">' +
      '<p style="margin:0"><b>' + esc(o.customer_name) + '</b> · ' + esc(o.source) + ' · Layanan: ' + esc(svc ? svc.name : (o.service_name_snapshot || '–')) + '</p>' +
      '<p class="muted" style="margin:0">Masuk ' + fmtDate(o.received_at, tz) + ' · Deadline ' + (o.deadline ? fmtDate(o.deadline, tz) : '–') + ' · Prioritas ' + esc(o.priority) + ' · Status <b>' + esc(o.status) + '</b></p>' +
      (o.needs_summary ? '<p style="margin:0"><b>Kebutuhan:</b> ' + esc(o.needs_summary) + '</p>' : '') +
      (o.instructions ? '<p style="margin:0;white-space:pre-line"><b>Instruksi:</b> ' + esc(o.instructions) + '</p>' : '') +
      (o.internal_notes ? '<p style="margin:0;white-space:pre-line"><b>Catatan internal:</b> ' + esc(o.internal_notes) + '</p>' : '') +
      (o.delivered_at ? '<p class="muted" style="margin:0">Hasil tercatat terkirim: ' + fmtDate(o.delivered_at, tz) + '</p>' : '') +
      '<div class="btn-row">' +
      (wa ? '<a class="btn small" href="' + wa + '" target="_blank" rel="noopener noreferrer">Buka WhatsApp</a>' : '') +
      '<button class="btn secondary small" id="od-edit">Edit Pesanan</button>' +
      '<button class="btn secondary small" id="od-status">Ubah Status</button>' +
      '<button class="btn ghost small" id="od-copy-progress">Salin Pesan Progres</button>' +
      '<button class="btn ghost small" id="od-copy-result">Salin Pesan Hasil</button>' +
      '<button class="btn ghost small" id="od-delivered">Catat Hasil Terkirim</button>' +
      '</div></div></div>';

    // Pembayaran
    h += '<h2>Pembayaran</h2><div class="table-wrap" style="margin-bottom:10px"><table><thead><tr><th>Tanggal</th><th>Metode</th><th>Referensi</th><th class="num">Nominal</th><th class="num">Refund</th><th></th></tr></thead><tbody>' +
      (pays.length ? pays.map(function (p) {
        const rf = refundsOfPayment(p.id).reduce((a, r) => a + Number(r.amount), 0);
        return '<tr><td>' + fmtDate(p.pay_date, tz) + '</td><td>' + esc(p.method || '–') + '</td><td>' + esc(p.reference || '–') + '</td>' +
          '<td class="num">' + rp(p.amount) + '</td><td class="num">' + (rf ? rp(rf) : '–') + '</td>' +
          '<td><button class="btn ghost small" data-refund="' + p.id + '">Refund</button></td></tr>';
      }).join('') : '<tr><td colspan="6" class="muted">Belum ada pembayaran tercatat.</td></tr>') +
      '</tbody></table></div>' +
      '<form id="pay-form" class="form-grid two">' +
      field('Nominal (Rp) *', '<input name="amount" type="number" min="1" step="1" required>') +
      field('Tanggal', '<input name="pay_date" type="date" value="' + todayISO(tz) + '">') +
      field('Metode', input('method', '', 'placeholder="Transfer / QRIS / Tunai"')) +
      field('Referensi', input('reference', '')) +
      '<div class="field"><label>&nbsp;</label><button class="btn" type="submit">Tambah Pembayaran</button></div></form>';

    // Revisi
    h += '<h2 style="margin-top:22px">Revisi</h2>' +
      (revs.length ? '<div class="table-wrap" style="margin-bottom:10px"><table><thead><tr><th>Ke</th><th>Tanggal</th><th>Catatan</th></tr></thead><tbody>' +
        revs.map(r => '<tr><td>' + r.revision_no + '</td><td>' + fmtDate(r.rev_date, tz) + '</td><td>' + esc(r.note) + '</td></tr>').join('') +
        '</tbody></table></div>' : '<p class="muted">Belum ada revisi tercatat.</p>') +
      '<form id="rev-form" class="form-grid two">' +
      field('Catatan revisi *', '<input name="note" required>') +
      field('Tanggal', '<input name="rev_date" type="date" value="' + todayISO(tz) + '">') +
      '<div class="field"><label>&nbsp;</label><button class="btn secondary" type="submit">Catat Revisi</button></div></form>';

    // Lampiran
    h += '<h2 style="margin-top:22px">Lampiran</h2>' +
      (atts.length ? '<div class="table-wrap" style="margin-bottom:10px"><table><thead><tr><th>Label</th><th>Jenis</th><th>Tautan</th><th></th></tr></thead><tbody>' +
        atts.map(function (a, i) {
          return '<tr><td>' + esc(a.label || 'Lampiran') + '</td><td>' + esc(a.kind || '') + '</td>' +
            '<td>' + (a.url ? '<a href="' + esc(a.url) + '" target="_blank" rel="noopener noreferrer">Buka</a>' : (a.path ? '<button class="btn ghost small" data-open-private="' + i + '">Buka (privat)</button>' : '–')) + '</td>' +
            '<td><button class="btn ghost small" data-del-att="' + i + '">Hapus</button></td></tr>';
        }).join('') + '</tbody></table></div>' : '<p class="muted">Belum ada lampiran. Proses via chat tetap bisa berjalan tanpa lampiran di web.</p>') +
      '<form id="att-form" class="form-grid two">' +
      field('Label', '<input name="label" placeholder="cth: Foto sumber dari pelanggan">') +
      field('Jenis', selectHtml('kind', ['sumber', 'referensi', 'preview', 'final'], 'sumber')) +
      field('URL eksternal (atau unggah file di bawah)', '<input name="url" placeholder="https://…">') +
      field('Unggah file privat', '<input name="file" type="file" accept="image/*,.pdf,.zip">') +
      '<div class="field"><label>&nbsp;</label><button class="btn secondary" type="submit">Tambah Lampiran</button></div></form>';

    return {
      html: shell('/admin/pesanan', 'Pesanan ' + (o.code || ''), h),
      mount: function (root) {
        mountShell(root);
        root.querySelector('#od-edit').addEventListener('click', function () { orderFormDialog(o); });
        root.querySelector('#od-status').addEventListener('click', function () {
          const d = dialog('Ubah Status Pesanan', '<form id="st-form">' +
            field('Status pengerjaan', selectHtml('status', ORDER_STATUSES, o.status)) +
            '<button class="btn" type="submit">Simpan Status</button></form>');
          d.el.querySelector('#st-form').addEventListener('submit', async function (e) {
            e.preventDefault();
            const data = formData(e.target);
            try {
              await DB.update('studio_orders', o.id, { status: data.status, updated_at: new Date().toISOString() });
              toast('Status diperbarui. Menandai Selesai tidak mengubah pembayaran.');
              d.close(); await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
            } catch (ex) { toast(ex.message, true); }
          });
        });
        function copyText(text, okMsg) {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () { toast(okMsg); }, function () { toast('Gagal menyalin.', true); });
          } else { toast('Clipboard tidak tersedia di browser ini.', true); }
        }
        root.querySelector('#od-copy-progress').addEventListener('click', function () {
          copyText('Halo ' + o.customer_name + ', pesananmu ' + (o.code || '') + ' saat ini berstatus: ' + o.status + '. Kami kabari lagi begitu ada perkembangan. Terima kasih sudah menunggu.', 'Pesan progres disalin. Tempel dan kirim sendiri via WhatsApp.');
        });
        root.querySelector('#od-copy-result').addEventListener('click', function () {
          copyText('Halo ' + o.customer_name + ', hasil edit pesanan ' + (o.code || '') + ' sudah selesai. Silakan dicek, kalau ada yang perlu direvisi tinggal kabari kami ya. Terima kasih sudah memakai FNATIX ID.', 'Pesan hasil disalin. Tempel dan kirim sendiri via WhatsApp.');
        });
        root.querySelector('#od-delivered').addEventListener('click', async function () {
          try {
            await DB.update('studio_orders', o.id, { delivered_at: todayISO(tz), updated_at: new Date().toISOString() });
            toast('Tanggal terkirim dicatat.');
            await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
          } catch (e) { toast(e.message, true); }
        });
        root.querySelector('#pay-form').addEventListener('submit', async function (e) {
          e.preventDefault();
          const data = formData(e.target);
          const amount = parseMoney(data.amount);
          if (!amount || amount <= 0) { toast('Nominal pembayaran tidak valid.', true); return; }
          if (orderPaidGross(o.id) + amount > total) {
            toast('Pembayaran melebihi sisa tagihan (' + rp(sisa) + '). Untuk MVP, pembayaran di atas sisa ditolak.', true);
            return;
          }
          try {
            await DB.insert('studio_payments', { order_id: o.id, amount, pay_date: data.pay_date || todayISO(tz), method: data.method || '', reference: data.reference || '' });
            toast('Pembayaran tercatat sebagai satu entri keuangan.');
            await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
          } catch (ex) { toast(ex.message, true); }
        });
        root.querySelectorAll('[data-refund]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            const pid = btn.getAttribute('data-refund');
            const pay = S.payments.find(p => p.id === pid);
            const d = dialog('Catat Refund', '<form id="rf-form">' +
              field('Nominal refund (Rp) *', '<input name="amount" type="number" min="1" max="' + (pay ? pay.amount : '') + '" required>') +
              field('Tanggal', '<input name="refund_date" type="date" value="' + todayISO(tz) + '">') +
              field('Alasan', '<input name="reason">') +
              '<p class="small muted">Refund mengurangi arus kas dan tidak menghapus histori pembayaran awal.</p>' +
              '<button class="btn danger" type="submit">Simpan Refund</button></form>');
            d.el.querySelector('#rf-form').addEventListener('submit', async function (e) {
              e.preventDefault();
              const data = formData(e.target);
              const amount = parseMoney(data.amount);
              const already = refundsOfPayment(pid).reduce((a, r) => a + Number(r.amount), 0);
              if (!amount || amount <= 0 || (pay && already + amount > Number(pay.amount))) { toast('Nominal refund tidak valid atau melebihi pembayaran.', true); return; }
              try {
                await DB.insert('studio_refunds', { payment_id: pid, amount, refund_date: data.refund_date || todayISO(tz), reason: data.reason || '' });
                toast('Refund tercatat.');
                d.close(); await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
              } catch (ex) { toast(ex.message, true); }
            });
          });
        });
        root.querySelector('#rev-form').addEventListener('submit', async function (e) {
          e.preventDefault();
          const data = formData(e.target);
          try {
            await DB.insert('studio_order_revisions', { order_id: o.id, revision_no: revs.length + 1, note: data.note, rev_date: data.rev_date || todayISO(tz) });
            if (o.status !== 'Revisi') await DB.update('studio_orders', o.id, { status: 'Revisi', updated_at: new Date().toISOString() });
            toast('Revisi dicatat.');
            await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
          } catch (ex) { toast(ex.message, true); }
        });
        root.querySelector('#att-form').addEventListener('submit', async function (e) {
          e.preventDefault();
          const form = e.target;
          const data = formData(form);
          const file = form.querySelector('[name=file]').files[0];
          try {
            let entry = { label: data.label || 'Lampiran', kind: data.kind, url: data.url || '' };
            if (file) {
              const path = 'orders/' + o.id + '/' + uid() + '-' + file.name.replace(/[^\w.\-]+/g, '_');
              await DB.upload('studio-privat', path, file);
              await DB.insert('studio_assets', { storage_path: path, bucket: 'studio-privat', visibility: 'private', mime: file.type || '', size_bytes: file.size, parent_type: 'order', parent_id: o.id, role: 'lampiran' });
              entry = { label: data.label || file.name, kind: data.kind, path: path };
            } else if (!entry.url) { toast('Isi URL atau pilih file dulu.', true); return; }
            const next = atts.concat([entry]);
            await DB.update('studio_orders', o.id, { attachments: next, updated_at: new Date().toISOString() });
            toast('Lampiran ditambahkan.');
            await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
          } catch (ex) { toast(ex.message, true); }
        });
        root.querySelectorAll('[data-del-att]').forEach(function (btn) {
          btn.addEventListener('click', async function () {
            if (!(await confirmDialog('Hapus lampiran ini dari pesanan? File di storage tidak ikut terhapus.'))) return;
            const next = atts.filter((_, i) => i !== Number(btn.getAttribute('data-del-att')));
            try {
              await DB.update('studio_orders', o.id, { attachments: next, updated_at: new Date().toISOString() });
              await loadAll(); window.dispatchEvent(new PopStateEvent('popstate'));
            } catch (e) { toast(e.message, true); }
          });
        });
        root.querySelectorAll('[data-open-private]').forEach(function (btn) {
          btn.addEventListener('click', async function () {
            const a = atts[Number(btn.getAttribute('data-open-private'))];
            if (!a || !a.path) return;
            try {
              const url = await DB.signedUrl('studio-privat', a.path, 600);
              window.open(url, '_blank', 'noopener');
            } catch (e) { toast(e.message, true); }
          });
        });
      }
    };
  }

  window.Admin = {
    _part: 'orders',
    get S() { return S; },
    set S(v) { S = v; },
    loadAll, shell, mountShell, dialog, confirmDialog, field, input, textarea, selectHtml, formData, handle, toast,
    loginPage, mountLogin, dashboardPage, ordersPage, orderDetailPage,
    orderPaidNet, orderPaidGross, orderTotal, orderPayStatus, salePaidNet, saleTotal, salePayStatus,
    ORDER_STATUSES, ACTIVE_STATUSES
  };
})();
